# Dojo Survey

You need to build a form to submit post information to your server, and then render that information on a results page so you can survey your friends on their favorite languages!

## Topics:
● POST

## Tasks:
● Create a 2 page app that will allow clients to fill out a form and see the form results.

## Optional Challenges:
● Can you render a third page for anyone that chooses "java" as their favorite language?
