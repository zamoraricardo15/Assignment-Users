package com.example.dojosurvey;

import org.junit.jupiter.api.Test;
//import org.junit.Test;
//import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;

//@RunWith(SpringRunner.class)
@SpringBootTest
public class DojoSurveyApplicationTests {

	@Test
	public void contextLoads() {
	}

}
